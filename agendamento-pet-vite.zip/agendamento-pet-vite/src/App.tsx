import React, { useEffect, useMemo, useState } from "react";

type Appointment = {
  id: string;
  petName: string;
  ownerName: string;
  service: string;
  date: string; // yyyy-mm-dd
  time: string; // HH:MM (24h)
  notes?: string;
};

const STORAGE_KEY = "agendamentos_pet_v1";

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function getPeriod(time: string): "manhã" | "tarde" | "noite" {
  const [hStr, mStr] = time.split(":");
  const h = Number(hStr);
  const minutes = h * 60 + Number(mStr || 0);
  if (minutes < 12 * 60) return "manhã"; // 00:00–11:59
  if (minutes < 18 * 60) return "tarde"; // 12:00–17:59
  return "noite"; // 18:00–23:59
}

function formatDateBR(yyyyMmDd: string) {
  if (!yyyyMmDd) return "";
  const [y, m, d] = yyyyMmDd.split("-");
  return `${d}/${m}/${y}`;
}

function classNames(...xs: Array<string | false | null | undefined>) {
  return xs.filter(Boolean).join(" ");
}

export default function AppAgendamentoPet() {
  const [items, setItems] = useState<Appointment[]>([]);
  const [filterDate, setFilterDate] = useState<string>("");

  // Form state
  const [petName, setPetName] = useState("");
  const [ownerName, setOwnerName] = useState("");
  const [service, setService] = useState("");
  const [date, setDate] = useState<string>("");
  const [time, setTime] = useState<string>("");
  const [notes, setNotes] = useState<string>("");
  const [error, setError] = useState<string>("");
  const [toast, setToast] = useState<string>("");

  useEffect(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        setItems(JSON.parse(raw));
      } catch {
        // ignore
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [items]);

  const filtered = useMemo(() => {
    if (!filterDate) return items;
    return items.filter((x) => x.date === filterDate);
  }, [items, filterDate]);

  const grouped = useMemo(() => {
    const g: Record<string, Appointment[]> = { manhã: [], tarde: [], noite: [] };
    filtered.forEach((x) => g[getPeriod(x.time)].push(x));
    (Object.keys(g) as Array<keyof typeof g>).forEach((k) => {
      g[k].sort((a, b) => (a.time < b.time ? -1 : a.time > b.time ? 1 : 0));
    });
    return g;
  }, [filtered]);

  const counts = {
    manhã: grouped["manhã"].length,
    tarde: grouped["tarde"].length,
    noite: grouped["noite"].length,
  };

  function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    if (!petName || !ownerName || !service || !date || !time) {
      setError("Preencha pet, tutor, serviço, data e hora.");
      return;
    }

    const newItem: Appointment = {
      id: uid(),
      petName: petName.trim(),
      ownerName: ownerName.trim(),
      service: service.trim(),
      date,
      time,
      notes: notes?.trim() || undefined,
    };

    setItems((prev) => [newItem, ...prev]);
    setToast("Agendamento adicionado!");

    setPetName("");
    setOwnerName("");
    setService("");
    setDate("");
    setTime("");
    setNotes("");
  }

  function handleDelete(id: string) {
    setItems((prev) => prev.filter((x) => x.id !== id));
    setToast("Agendamento excluído.");
  }

  function handleClearAll() {
    if (confirm("Deseja apagar TODOS os agendamentos?")) {
      setItems([]);
      setToast("Agenda limpa.");
    }
  }

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 2200);
    return () => clearTimeout(t);
  }, [toast]);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="sticky top-0 z-10 bg-white/90 backdrop-blur border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-violet-600 text-white text-xl font-bold shadow">🐾</span>
            <div className="leading-tight">
              <h1 className="text-xl sm:text-2xl font-extrabold">Agendamento Pet</h1>
              <p className="text-xs sm:text-sm text-gray-500">Gerencie os horários por período do dia</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleClearAll}
              className="px-3 py-2 rounded-xl border border-gray-300 text-sm hover:bg-gray-100 active:scale-[.98]"
              title="Limpar todos"
            >
              Limpar agenda
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <section className="lg:col-span-1">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4 sm:p-6">
            <h2 className="text-lg font-semibold mb-4">Novo agendamento</h2>
            {error && (
              <div className="mb-4 rounded-xl border border-red-200 bg-red-50 text-red-700 px-3 py-2 text-sm">
                {error}
              </div>
            )}
            <form onSubmit={handleAdd} className="grid grid-cols-1 gap-3">
              <div>
                <label className="block text-sm font-medium mb-1">Pet</label>
                <input
                  className="w-full rounded-xl border border-gray-300 px-3 py-2 outline-none focus:ring-2 focus:ring-violet-500"
                  value={petName}
                  onChange={(e) => setPetName(e.target.value)}
                  placeholder="Nome do pet"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Tutor</label>
                <input
                  className="w-full rounded-xl border border-gray-300 px-3 py-2 outline-none focus:ring-2 focus:ring-violet-500"
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  placeholder="Nome do tutor"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Serviço</label>
                <input
                  className="w-full rounded-xl border border-gray-300 px-3 py-2 outline-none focus:ring-2 focus:ring-violet-500"
                  value={service}
                  onChange={(e) => setService(e.target.value)}
                  placeholder="Banho, tosa, consulta..."
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium mb-1">Data</label>
                  <input
                    type="date"
                    className="w-full rounded-xl border border-gray-300 px-3 py-2 outline-none focus:ring-2 focus:ring-violet-500"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Hora</label>
                  <input
                    type="time"
                    className="w-full rounded-xl border border-gray-300 px-3 py-2 outline-none focus:ring-2 focus:ring-violet-500"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Observações</label>
                <textarea
                  className="w-full rounded-xl border border-gray-300 px-3 py-2 outline-none focus:ring-2 focus:ring-violet-500 min-h-[72px]"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Detalhes, alergias, recados..."
                />
              </div>
              <button
                type="submit"
                className="mt-1 rounded-2xl bg-violet-600 text-white font-semibold px-4 py-2 hover:bg-violet-700 active:scale-[.98]"
              >
                Adicionar agendamento
              </button>
            </form>
          </div>

          <div className="mt-6 bg-white rounded-2xl shadow-sm border border-gray-200 p-4 sm:p-6">
            <h3 className="text-base font-semibold mb-3">Filtrar por data</h3>
            <div className="flex items-center gap-3">
              <input
                type="date"
                className="w-full rounded-xl border border-gray-300 px-3 py-2 outline-none focus:ring-2 focus:ring-violet-500"
                value={filterDate}
                onChange={(e) => setFilterDate(e.target.value)}
              />
              {filterDate && (
                <button
                  onClick={() => setFilterDate("")}
                  className="rounded-xl border border-gray-300 px-3 py-2 hover:bg-gray-100"
                >
                  Limpar
                </button>
              )}
            </div>
            <p className="text-sm text-gray-500 mt-2">
              {filterDate ? `Mostrando agendamentos de ${formatDateBR(filterDate)}` : "Mostrando todos os agendamentos"}
            </p>
          </div>
        </section>

        <section className="lg:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
          <PeriodColumn title="Manhã" count={counts.manhã} accent="bg-amber-100" icon="☀️">
            {grouped["manhã"].map((a) => (
              <AppointmentCard key={a.id} a={a} onDelete={() => handleDelete(a.id)} />
            ))}
          </PeriodColumn>
          <PeriodColumn title="Tarde" count={counts.tarde} accent="bg-sky-100" icon="🌤️">
            {grouped["tarde"].map((a) => (
              <AppointmentCard key={a.id} a={a} onDelete={() => handleDelete(a.id)} />
            ))}
          </PeriodColumn>
          <PeriodColumn title="Noite" count={counts.noite} accent="bg-indigo-100" icon="🌙">
            {grouped["noite"].map((a) => (
              <AppointmentCard key={a.id} a={a} onDelete={() => handleDelete(a.id)} />
            ))}
          </PeriodColumn>
        </section>
      </main>

      <div
        className={classNames(
          "fixed left-1/2 -translate-x-1/2 bottom-6 z-50 transition-all duration-300",
          toast ? "opacity-100 translate-y-0" : "opacity-0 translate-y-3 pointer-events-none"
        )}
      >
        <div className="rounded-2xl bg-gray-900 text-white/90 px-4 py-2 shadow-lg text-sm">{toast}</div>
      </div>

      <footer className="border-t border-gray-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 py-6 text-xs text-gray-500 flex items-center justify-between">
          <span>© {new Date().getFullYear()} Petshop – Agenda</span>
          <span>LocalStorage • Responsivo • Períodos do dia</span>
        </div>
      </footer>
    </div>
  );
}

function PeriodColumn({
  title,
  count,
  icon,
  accent,
  children,
}: {
  title: string;
  count: number;
  icon: string;
  accent: string;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-200 flex flex-col">
      <div className={`px-4 py-3 rounded-t-2xl border-b border-gray-200 flex items-center justify-between ${accent}`}>
        <div className="flex items-center gap-2">
          <span className="text-lg">{icon}</span>
          <h3 className="font-semibold">{title}</h3>
        </div>
        <span className="text-xs bg-white/70 border border-gray-200 rounded-full px-2 py-0.5">{count}</span>
      </div>
      <div className="p-3 sm:p-4 space-y-3 overflow-auto max-h-[60vh]">
        {count === 0 ? <p className="text-sm text-gray-500">Sem agendamentos neste período.</p> : children}
      </div>
    </div>
  );
}

function AppointmentCard({ a, onDelete }: { a: Appointment; onDelete: () => void }) {
  return (
    <div className="rounded-2xl border border-gray-200 p-3 sm:p-4 shadow-sm hover:shadow transition bg-white">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-violet-100 text-violet-700">🐶</span>
            <div className="min-w-0">
              <p className="font-semibold truncate">
                {a.petName} <span className="font-normal text-gray-400">• {a.time}</span>
              </p>
              <p className="text-xs text-gray-500 truncate">
                {a.service} — Tutor: {a.ownerName}
              </p>
            </div>
          </div>
        </div>
        <button
          onClick={onDelete}
          className="shrink-0 rounded-xl border border-red-200 text-red-700 text-sm px-3 py-1.5 hover:bg-red-50 active:scale-[.98]"
          title="Excluir"
        >
          Excluir
        </button>
      </div>
      <div className="mt-2 text-xs text-gray-500 flex items-center justify-between">
        <span>{formatDateBR(a.date)}</span>
        {a.notes && (
          <span className="truncate max-w-[50%]" title={a.notes}>
            {a.notes}
          </span>
        )}
      </div>
    </div>
  );
}
