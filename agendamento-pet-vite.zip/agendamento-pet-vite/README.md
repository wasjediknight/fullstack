# Agendamento Pet — Vite + React + TypeScript

Aplicação responsiva de agendamento para petshop.

## Funcionalidades
- Adicionar agendamento
- Visualizar por período (manhã, tarde, noite)
- Excluir agendamento
- Filtrar por data
- Persistência em `localStorage`

## Rodando o projeto
```bash
npm i
npm run dev
```
Abra o endereço mostrado pelo Vite (geralmente `http://localhost:5173`).

## Build de produção
```bash
npm run build
npm run preview
```
Isso gera arquivos estáticos em `dist/`.
